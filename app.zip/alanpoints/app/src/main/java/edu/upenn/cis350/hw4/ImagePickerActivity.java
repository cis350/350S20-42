package edu.upenn.cis350.hw4;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ImagePickerActivity extends AppCompatActivity {




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_picker);
    }
}
