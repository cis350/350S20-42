package edu.upenn.cis350.hw4.data;

public class Vaccine {
    String id;
    //Date date;
    String hospitalId;
    Boolean verified;
}
